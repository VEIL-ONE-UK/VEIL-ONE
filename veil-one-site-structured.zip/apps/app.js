const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
let snake = [{x: 10, y: 10}];
let dir = {x: 1, y: 0};
let food = {x: 5, y: 5};
let score = 0;
const status = document.getElementById("status");

function draw() {
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle = "white";
  snake.forEach(s => ctx.fillRect(s.x*18, s.y*18, 16, 16));
  ctx.fillRect(food.x*18, food.y*18, 16, 16);
}
function step() {
  const head = {x: snake[0].x + dir.x, y: snake[0].y + dir.y};
  snake.unshift(head);
  if (head.x === food.x && head.y === food.y) {
    score++;
    food = {x: Math.floor(Math.random()*18), y: Math.floor(Math.random()*18)};
    if (score >= 5) {
      localStorage.setItem("unlocked","1");
      status.textContent = "UNLOCKED — Refresh to enter";
    }
  } else snake.pop();
  draw();
}
document.addEventListener("keydown", e => {
  if (e.key === "ArrowUp") dir = {x:0,y:-1};
  if (e.key === "ArrowDown") dir = {x:0,y:1};
  if (e.key === "ArrowLeft") dir = {x:-1,y:0};
  if (e.key === "ArrowRight") dir = {x:1,y:0};
});
setInterval(step, 200);
draw();
if (localStorage.getItem("unlocked")==="1") {
  window.location.href = "info.html";
}
