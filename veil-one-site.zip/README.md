# VEIL / ONE — Static Site

A modern, minimalist static site intended for GitHub Pages.

## Features
- Center CTA: **ISSUED, NOT RELEASED**
- Embedded **Snake** game
- Unlock rule: when snake score reaches **5**, the **Info** page unlocks
- Unlock persists via `localStorage`
- No build step; pure HTML/CSS/JS

## Deploy to GitHub Pages
1. Create a repo (or use existing).
2. Upload these files to the repo root:
   - `index.html`
   - `info.html`
   - `style.css`
   - `app.js`
3. In GitHub: **Settings → Pages**
   - Source: `Deploy from a branch`
   - Branch: `main` (or `master`), folder: `/root`
4. Your site will appear at the GitHub Pages URL.

## Customize
- Unlock threshold: edit `UNLOCK_SCORE` in `app.js`
- Game speed: edit `SPEED_MS` in `app.js`
