// VEIL / ONE — snake protocol + unlock gateway
(() => {
  const UNLOCK_SCORE = 5;
  const STORAGE_KEY = "veil_one_unlocked_v1";
  const BEST_KEY = "veil_one_best_v1";

  // --- UI elements ---
  const yearEl = document.getElementById("year");
  yearEl.textContent = new Date().getFullYear();

  const scoreEl = document.getElementById("score");
  const bestEl = document.getElementById("best");
  const unlockStateEl = document.getElementById("unlockState");
  const scoreHintEl = document.getElementById("scoreHint");

  const cta = document.getElementById("cta");
  const enterInfo = document.getElementById("enterInfo");
  const gatewayBtn = document.getElementById("gatewayBtn");
  const modal = document.getElementById("gateway");
  const modalState = document.getElementById("modalState");
  const modalEnter = document.getElementById("modalEnter");
  const modalReset = document.getElementById("modalReset");
  const toast = document.getElementById("toast");

  // --- Unlock state ---
  function isUnlocked(){
    return localStorage.getItem(STORAGE_KEY) === "1";
  }
  function setUnlocked(v){
    localStorage.setItem(STORAGE_KEY, v ? "1" : "0");
    renderUnlock();
  }

  function renderUnlock(){
    const unlocked = isUnlocked();
    unlockStateEl.textContent = unlocked ? "UNLOCKED" : "LOCKED";
    unlockStateEl.style.color = unlocked ? "var(--good)" : "rgba(255,255,255,.78)";
    scoreHintEl.textContent = unlocked ? "GATEWAY OPEN" : "SNAKE // EAT 5 TO UNLOCK";

    enterInfo.disabled = !unlocked;
    enterInfo.textContent = unlocked ? "ENTER // INFO" : "ACCESS DENIED";

    modalEnter.disabled = !unlocked;
    modalEnter.textContent = unlocked ? "ENTER // INFO" : "ACCESS DENIED";

    cta.textContent = unlocked ? "ENTER // INFO" : "ISSUED, NOT RELEASED";
    modalState.textContent = unlocked ? "UNLOCKED" : "LOCKED";
  }

  function goInfo(){
    window.location.href = "info.html";
  }

  cta.addEventListener("click", () => {
    if (isUnlocked()) goInfo();
    else pulseToast("Locked. Complete protocol: score 5.");
  });

  enterInfo.addEventListener("click", () => {
    if (isUnlocked()) goInfo();
  });

  // --- Modal ---
  gatewayBtn.addEventListener("click", () => {
    if (typeof modal.showModal === "function") modal.showModal();
    else alert("Your browser does not support <dialog>. Open info.html after unlocking.");
  });

  modalEnter.addEventListener("click", () => {
    if (isUnlocked()) { modal.close(); goInfo(); }
  });

  modalReset.addEventListener("click", () => {
    setUnlocked(false);
    best = 0;
    localStorage.setItem(BEST_KEY, "0");
    bestEl.textContent = "0";
    reset();
    pulseToast("Unlock reset.");
  });

  // --- Toast ---
  let toastTimer = null;
  function pulseToast(msg){
    toast.textContent = msg;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 1800);
  }

  // --- Background subtle particles ---
  const bg = document.getElementById("bg");
  const bctx = bg.getContext("2d");
  const DPR = Math.min(2, window.devicePixelRatio || 1);
  function resizeBg(){
    bg.width = Math.floor(innerWidth * DPR);
    bg.height = Math.floor(innerHeight * DPR);
  }
  resizeBg();
  addEventListener("resize", resizeBg);

  const particles = Array.from({length: 70}, () => ({
    x: Math.random(),
    y: Math.random(),
    r: 0.6 + Math.random() * 1.6,
    vx: (Math.random() - 0.5) * 0.015,
    vy: (Math.random() - 0.5) * 0.015,
    a: 0.10 + Math.random() * 0.18
  }));

  function tickBg(){
    bctx.clearRect(0,0,bg.width,bg.height);
    bctx.save();
    bctx.scale(DPR, DPR);
    bctx.globalCompositeOperation = "lighter";
    for (const p of particles){
      p.x += p.vx; p.y += p.vy;
      if (p.x < -0.05) p.x = 1.05;
      if (p.x > 1.05) p.x = -0.05;
      if (p.y < -0.05) p.y = 1.05;
      if (p.y > 1.05) p.y = -0.05;

      const x = p.x * innerWidth;
      const y = p.y * innerHeight;
      bctx.beginPath();
      bctx.fillStyle = `rgba(255,255,255,${p.a})`;
      bctx.arc(x, y, p.r, 0, Math.PI*2);
      bctx.fill();
    }
    bctx.restore();
    requestAnimationFrame(tickBg);
  }
  tickBg();

  // --- Snake Game ---
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");

  const GRID = 18;                 // 18x18 cells
  const CELL = canvas.width / GRID; // assume square canvas
  const SPEED_MS = 110;            // lower is faster
  const FOOD_COUNT = 1;

  let muted = false;
  let paused = false;

  // simple beep (no external audio files)
  const audioCtx = (window.AudioContext || window.webkitAudioContext) ? new (window.AudioContext || window.webkitAudioContext)() : null;
  function beep(freq=440, dur=0.06, gain=0.03){
    if (muted || !audioCtx) return;
    try{
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = "sine";
      o.frequency.value = freq;
      g.gain.value = gain;
      o.connect(g); g.connect(audioCtx.destination);
      o.start();
      o.stop(audioCtx.currentTime + dur);
    }catch(_){}
  }

  let snake, dir, nextDir, food, score, best, loop;

  best = parseInt(localStorage.getItem(BEST_KEY) || "0", 10);
  bestEl.textContent = String(best);

  function randCell(){
    return { x: Math.floor(Math.random()*GRID), y: Math.floor(Math.random()*GRID) };
  }

  function occupied(x,y){
    return snake.some(s => s.x===x && s.y===y);
  }

  function placeFood(){
    const f = [];
    while (f.length < FOOD_COUNT){
      const c = randCell();
      if (!occupied(c.x,c.y) && !f.some(z => z.x===c.x && z.y===c.y)) f.push(c);
    }
    food = f;
  }

  function reset(){
    snake = [{x:9,y:10},{x:8,y:10},{x:7,y:10}];
    dir = {x:1,y:0};
    nextDir = {x:1,y:0};
    score = 0;
    scoreEl.textContent = "0";
    paused = false;
    placeFood();
    render();
  }

  function unlockIfNeeded(){
    if (score >= UNLOCK_SCORE && !isUnlocked()){
      setUnlocked(true);
      pulseToast("Unlocked. Gateway open.");
      beep(880, 0.08, 0.04);
      beep(1320, 0.08, 0.04);
    }
  }

  function gameOver(){
    beep(160, 0.10, 0.05);
    pulseToast("Protocol failed. Press R to reset.");
    paused = true;
    if (score > best){
      best = score;
      localStorage.setItem(BEST_KEY, String(best));
      bestEl.textContent = String(best);
      pulseToast("New best. Press R to try again.");
    }
  }

  function step(){
    if (paused) return;

    dir = nextDir;
    const head = snake[0];
    const nx = head.x + dir.x;
    const ny = head.y + dir.y;

    // wall collision
    if (nx < 0 || nx >= GRID || ny < 0 || ny >= GRID){
      gameOver(); return;
    }
    // self collision
    if (occupied(nx, ny)){
      gameOver(); return;
    }

    snake.unshift({x:nx,y:ny});

    // eat
    const hit = food.findIndex(f => f.x===nx && f.y===ny);
    if (hit !== -1){
      food.splice(hit,1);
      score++;
      scoreEl.textContent = String(score);
      beep(520, 0.04, 0.03);
      unlockIfNeeded();
      placeFood();
    } else {
      snake.pop();
    }
    render();
  }

  function render(){
    // background
    ctx.clearRect(0,0,canvas.width,canvas.height);

    // subtle grid
    ctx.save();
    ctx.globalAlpha = 0.18;
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 1;
    for(let i=1;i<GRID;i++){
      ctx.beginPath(); ctx.moveTo(i*CELL,0); ctx.lineTo(i*CELL,canvas.height); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0,i*CELL); ctx.lineTo(canvas.width,i*CELL); ctx.stroke();
    }
    ctx.restore();

    // food
    for (const f of food){
      ctx.beginPath();
      ctx.fillStyle = "rgba(255,255,255,.92)";
      ctx.arc((f.x+0.5)*CELL, (f.y+0.5)*CELL, CELL*0.22, 0, Math.PI*2);
      ctx.fill();
    }

    // snake
    for (let i=0;i<snake.length;i++){
      const s = snake[i];
      const pad = 2.5;
      const x = s.x*CELL + pad;
      const y = s.y*CELL + pad;
      const w = CELL - pad*2;
      const h = CELL - pad*2;

      const a = i===0 ? 0.95 : Math.max(0.28, 0.82 - i*0.03);
      ctx.fillStyle = `rgba(255,255,255,${a})`;
      roundRect(ctx, x, y, w, h, 6);
      ctx.fill();
    }

    // paused overlay
    if (paused){
      ctx.save();
      ctx.fillStyle = "rgba(0,0,0,.55)";
      ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle = "rgba(255,255,255,.95)";
      ctx.font = "600 14px Inter, system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("PAUSED", canvas.width/2, canvas.height/2 - 8);
      ctx.font = "400 12px Inter, system-ui, sans-serif";
      ctx.fillStyle = "rgba(255,255,255,.8)";
      ctx.fillText("SPACE to resume · R to reset", canvas.width/2, canvas.height/2 + 16);
      ctx.restore();
    }
  }

  function roundRect(ctx, x, y, w, h, r){
    const rr = Math.min(r, w/2, h/2);
    ctx.beginPath();
    ctx.moveTo(x+rr, y);
    ctx.arcTo(x+w, y, x+w, y+h, rr);
    ctx.arcTo(x+w, y+h, x, y+h, rr);
    ctx.arcTo(x, y+h, x, y, rr);
    ctx.arcTo(x, y, x+w, y, rr);
    ctx.closePath();
  }

  function setDir(dx, dy){
    // prevent reversing into itself
    if (snake.length > 1 && (dx === -dir.x && dy === -dir.y)) return;
    nextDir = {x:dx,y:dy};
  }

  addEventListener("keydown", (e) => {
    const k = e.key.toLowerCase();
    if (k === "arrowup" || k === "w") setDir(0,-1);
    else if (k === "arrowdown" || k === "s") setDir(0,1);
    else if (k === "arrowleft" || k === "a") setDir(-1,0);
    else if (k === "arrowright" || k === "d") setDir(1,0);
    else if (k === " "){
      paused = !paused;
      if (!paused) pulseToast("Resumed.");
      render();
    }
    else if (k === "r"){
      reset();
      pulseToast("Reset.");
    }
    else if (k === "m"){
      muted = !muted;
      pulseToast(muted ? "Muted." : "Sound on.");
    }
  });

  // game loop (setInterval for determinism)
  function start(){
    reset();
    renderUnlock();
    loop = setInterval(step, SPEED_MS);
    pulseToast("Protocol: score 5 to unlock.");
  }
  start();
})();
